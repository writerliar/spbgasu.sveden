$(document).ready(function(){
	
	/*$("#upb").click(function() {$(this).slideToggle();});*/
	$(".zag").click(function() {$(this).next(".raz").slideToggle();});
	 	
});
	