/*!
 * Button visually impaired v1.0.6
 */
jQuery(document).ready(function($) {
    /*
    if (bvi['bvi_setting'].BviPanelActive == 1) {
        $().bvi('Active', bvi['bvi_setting']);
    } else {
        $('.bvi-panel-open').bvi('Init', bvi['bvi_setting']);
    }
    */
    $('.bvi-panel-open').bvi('Init');
});